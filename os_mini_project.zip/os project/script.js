function parsePages() {
    const input = document.getElementById("pageInput").value;
    return input.split(',').map(x => parseInt(x.trim())).filter(x => !isNaN(x));
  }
  
  function runSelectedAlgorithm() {
    const pages = parsePages();
    const frames = parseInt(document.getElementById("frameSize").value);
    const algo = document.getElementById("algoSelect").value;
    let result = "";
  
    switch (algo) {
      case "fifo":
        result = runFIFO(pages, frames);
        break;
      case "lru":
        result = runLRU(pages, frames);
        break;
      case "optimal":
        result = runOptimal(pages, frames);
        break;
      default:
        result = "Unknown algorithm.";
    }
  
    document.getElementById("result").textContent = result;
  }
  
  function runFIFO(pages, capacity) {
    let memory = [], faults = 0, log = "FIFO:\n";
    for (let page of pages) {
      if (!memory.includes(page)) {
        if (memory.length === capacity) memory.shift();
        memory.push(page);
        faults++;
      }
      log += `Page ${page} → [${memory.join(', ')}]\n`;
    }
    return log + `Page Faults: ${faults}`;
  }
  
  function runLRU(pages, capacity) {
    let memory = [], faults = 0, log = "LRU:\n";
    for (let page of pages) {
      let idx = memory.indexOf(page);
      if (idx !== -1) memory.splice(idx, 1);
      else {
        if (memory.length === capacity) memory.shift();
        faults++;
      }
      memory.push(page);
      log += `Page ${page} → [${memory.join(', ')}]\n`;
    }
    return log + `Page Faults: ${faults}`;
  }
  
  function runOptimal(pages, capacity) {
    let memory = [], faults = 0, log = "Optimal:\n";
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      if (!memory.includes(page)) {
        if (memory.length < capacity) {
          memory.push(page);
        } else {
          const future = pages.slice(i + 1);
          const indices = memory.map(p => {
            const idx = future.indexOf(p);
            return idx === -1 ? Infinity : idx;
          });
          const replaceIndex = indices.indexOf(Math.max(...indices));
          memory[replaceIndex] = page;
        }
        faults++;
      }
      log += `Page ${page} → [${memory.join(', ')}]\n`;
    }
    return log + `Page Faults: ${faults}`;
  }
  